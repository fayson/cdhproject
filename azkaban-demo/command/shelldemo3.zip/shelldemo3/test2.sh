#!/usr/bin/env bash
sleep 30

echo 'flowb job！！！' >> /tmp/test.log
