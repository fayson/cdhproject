#!/usr/bin/env bash
sleep 20

echo 'flowa job！！！' > /tmp/test.log
